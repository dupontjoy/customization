// ==UserScript==
// @name         PORNHUB Downloader
// @namespace    https://levelkro.com
// @version      0.3
// @description  PornHub find Video Links for download
// @author       levelKro (https://levelkro.com)
// @match        https://*.pornhub.com/*
// @grant        none
// @license		 MIT
// @copyright 2018, levelKro (https://levelkro.com) (https://openuserjs.org/users/levelKro)
// ==/UserScript==
console.log("PornHub Downloader loaded...");
setTimeout(function(){
document.getElementById("js-shareData").style.width="100%";
    //document.querySelector(".tab-menu-wrapper-cell").style.marginRight="5px";
    if(ad_player_id) {
        console.log("PORNHUB Downloader : Found video ID:"+ad_player_id);
        var v = window["flashvars_"+ad_player_id];
        console.log("PORNHUB Downloader : Try to find variable named 'flashvars_"+ad_player_id+"'");
        var a = Object.values(v);
        a.forEach(function(entry) {
            var box = document.querySelector(".tab-menu-wrapper-row");
            if(entry.length>=20){
                var c = entry.indexOf(".mp4");
                if(c!="-1") {
                    var f = false;
                    if(entry.indexOf("720P")!="-1") f = "720P";
                    else if(entry.indexOf("480P")!="-1") f = "480P";
                    else if(entry.indexOf("240P")!="-1") f = "240P";
                    else f = false;
                    if(f!==false) box.innerHTML += '<div class="tab-menu-wrapper-cell"><a class="tab-menu-item tooltipTrig" data-tab="download-tab" target="_blank" href="'+entry+'" data-title="Download at '+f+'"><i class="main-sprite-dark-2"></i><span>In '+f+'</span></a></div>';
                }
            }
        });

    }
},5000);
